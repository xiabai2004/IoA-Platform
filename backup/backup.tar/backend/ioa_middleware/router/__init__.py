"""IoA 路由模块

提供两种路由引擎：
1. WeightedRouter: 多维加权路由（基础版，无外部依赖）
2. EmbeddingRouter: Embedding 语义路由（高级版，需要 sentence-transformers）

SmartRouter 会自动选择最佳可用的路由引擎。
"""

import logging
from typing import Optional

logger = logging.getLogger("router")


class SmartRouter:
    """智能路由器 — 自动选择最佳可用的路由引擎

    优先使用 EmbeddingRouter（语义理解更好），
    不可用时降级为 WeightedRouter（关键词匹配）。
    """

    def __init__(self):
        self._router = None
        self._router_type = None
        self._initialized = False

    def _ensure_initialized(self):
        """延迟初始化路由引擎"""
        if self._initialized:
            return

        self._initialized = True

        # 尝试加载 EmbeddingRouter
        try:
            from ioa_middleware.router.embedding_router import get_embedding_router
            router = get_embedding_router()
            router._ensure_initialized()
            if router._model is not None:
                self._router = router
                self._router_type = "embedding"
                logger.info("Using EmbeddingRouter (semantic matching)")
                return
        except Exception as e:
            logger.info("EmbeddingRouter not available: %s", e)

        # 降级为 WeightedRouter
        from ioa_middleware.router.weighted_router import WeightedRouter
        self._router = WeightedRouter()
        self._router_type = "weighted"
        logger.info("Using WeightedRouter (keyword matching)")

    @property
    def router_type(self) -> str:
        """返回当前使用的路由引擎类型"""
        self._ensure_initialized()
        return self._router_type or "unknown"

    def select(
        self,
        candidates: list[dict],
        capability: str,
        domain: Optional[str] = None,
        task_desc: str = "",
    ) -> Optional[dict]:
        """从候选 Agent 中选择最佳的一个"""
        self._ensure_initialized()
        return self._router.select(candidates, capability, domain, task_desc)


# ── 导出 ──────────────────────────────────────────────────

__all__ = ["SmartRouter", "WeightedRouter", "EmbeddingRouter"]

# 延迟导入，避免循环依赖
def WeightedRouter():
    from ioa_middleware.router.weighted_router import WeightedRouter as WR
    return WR()

def EmbeddingRouter():
    from ioa_middleware.router.embedding_router import EmbeddingRouter as ER
    return ER()
